#!/bin/bash

##########  Server Admin Backup Script #####################
##
##	Written by Beau Hunter, Zack Smith  7/03/09
##  beauh@mac.com acid@wallcity.org
##  Server Admin backup script, equivallent to serveradmin settings all
##  backs up only when config changes, generates diffs with each change.
##
###############################################################################

#### User configuration ####

BACKUPDIR=/Auto\ Server\ Setup  ## for non-local BACKUPDEST, path is 
                                ## relative to the network mount
BACKUPDEST="nfs,local,smb,afp"  ## accepts 'afp','smb','nfs','local', or any combination

## AFP configurations 
AFPSERVER="server.com"  ## IP or DNS
AFPSHARE="Share"        ## Name of AFP share
AFPUSER="afpuser"       ## AFP login name
AFPPASS="afppass"       ## AFP password. Leave blank for Kerb.
AFPMOUNTPOINT="/Volumes/${AFPShare}"    ## AFP share mountpoint

## NFS configurations
NFSSERVER=hax.lbc
NFSURI="${NFSSERVER}:/Volumes/nfsshare"
NFSMOUNTPOINT="/Volumes/nfsshare"

## SMB configurations 
SMBSERVER="server.com"   ## IP or DNS
SMBSHARE="smbshare"      ## Name of SMB share
SMBUSER="smbuser"        ## SMB login name
SMBPASS="smbpass"        ## SMB password
SMBMOUNTPOINT="/Volumes/${SMBSHARE}"  ## SMB share mountpoint



#### STATIC CONFIG ####

## Serveradmin archive disk image
SABACKUPDMG="serveradmin_archives.sparsebundle"
SABACKUPMOUNTPOINT="/Volumes/${SABACKUPDMG%.sparsebundle}"


## Bin vars
declare -x mount="/sbin/mount"
declare -x grep="/usr/bin/grep"
declare -x serveradmin="/usr/sbin/serveradmin"
declare -x defaults="/usr/bin/defaults"
declare -x hdiutil="/usr/bin/hdiutil"
declare -x diskutil="/usr/sbin/diskutil"
declare -x mkdir="/bin/mkdir"
declare -x du="/usr/bin/du"
declare -x date="/bin/date"
declare -x diff="/usr/bin/diff"
declare -x awk="/usr/bin/awk"
declare -x mv="/bin/mv"
declare -x ln="/bin/ln"
declare -x mktemp="/usr/bin/mktemp"
declare -x umount="/sbin/umount"
declare -x sleep="/bin/sleep"

##  Runtime varibles
DATE=$("$date" +'%Y%m%d.%H%M_%S')
declare -x REQCMDS="$awk,$ntpdate,$perl,$scutil"
declare -x SCRIPT="${0##*/}" ; SCRIPTNAME="${SCRIPT%%\.*}"
declare -x SCRIPTPATH="$0" RUNDIRECTORY="${0%/*}"
declare -x SYSTEMVERSION="/System/Library/CoreServices/SystemVersion.plist"
declare -x OSVER="$("$defaults" read "${SYSTEMVERSION%.plist}" ProductVersion )"
#declare -x CONFIGFILE="${RUNDIRECTORY:?}/${SCRIPTNAME}.conf"
declare -x BUILDVERSION="20090703"

## test for root
[ "$EUID" != 0 ] && printf "%s\n" "This script requires root access ($EUID)!" && exit 1

# -- Start the script log
# Set to "VERBOSE" for more logging prior to using -v
declare -x LOGLEVEL="NORMAL" SCRIPTLOG="/Library/Logs/${SCRIPT%%\.*}.log"

declare -i CURRENT_LOG_SIZE="$("$du" -hm "${SCRIPTLOG:?}" |
                                "$awk" '/^[0-9]/{print $1;exit}')"

if [ ${CURRENT_LOG_SIZE:=0} -gt 50 ] ; then
	"$rm" "$SCRIPTLOG"
        statusMessage "LOGSIZE:$CURRENT_LOG_SIZE, too large removing"
fi

exec 2>>"${SCRIPTLOG:?}" # Redirect standard error to log file
# Strip any extention from scriptname and log stderr to script log
if [ -n ${SCRIPTLOG:?"The script log has not been specified"} ] ; then
	printf "%s\n" \
"STARTED:$SCRIPTNAME:EUID:$EUID:$("$date" +%H:%M:%S): Mac OS X $OSVER:BUILD:$BUILDVERSION" >>"${SCRIPTLOG:?}"
	printf "%s\n" "Log file is: ${SCRIPTLOG:?}"
fi

statusMessage() { # Status message function with type and now color!
# Requires SCRIPTLOG STATUS_TYPE=1 STATUS_MESSAGE=2

declare date="${date:="/bin/date"}"
declare DATE="$("$date" -u "+%Y-%m-%d")"
declare STATUS_TYPE="$1" STATUS_MESSAGE="$2"
if [ "$ENABLECOLOR" = "YES"  ] ; then
	# Background Color
	declare REDBG="41" WHITEBG="47" BLACKBG="40"
	declare YELLOWBG="43" BLUEBG="44" GREENBG="42"
	# Foreground Color
	declare BLACKFG="30" WHITEFG="37" YELLOWFG="33"
	declare BLUEFG="36" REDFG="31"
	declare BOLD="1" NOTBOLD="0"
	declare format='\033[%s;%s;%sm%s\033[0m\n'
	# "Bold" "Background" "Forground" "Status message"
	printf '\033[0m' # Clean up any previous color in the prompt
else
	declare format='%s\n'
fi
# Function only seems to work on intel and higher.
showUIDialog(){
statusMessage header "FUNCTION: #	$FUNCNAME" ; unset EXITVALUE TRY
"$killall" -HUP "System Events" 2>/dev/null
declare -x UIMESSAGE="$1"
"$osascript" <<EOF
try
with timeout of 0.1 seconds
	tell application "System Events"
		set UIMESSAGE to (system attribute "UIMESSAGE") as string
		activate
			display dialog UIMESSAGE with icon 2 giving up after "3600" buttons "Dismiss" default button "Dismiss"
		end tell
	end timeout
end try
EOF
return 0
} # END showUIDialog()
case "${STATUS_TYPE:?"Error status message with null type"}" in
	progress) \
	[ -n "$LOGLEVEL" ] &&
	printf $format $NOTBOLD $WHITEBG $BLACKFG "PROGRESS:$STATUS_MESSAGE"  ;
	printf "%s\n" "$DATE:PROGRESS: $STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;;
	# Used for general progress messages, always viewable
	
	notice) \
	printf "%s\n" "$DATE:NOTICE:$STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;
	[ -n "$LOGLEVEL" ] &&
	printf $format $NOTBOLD $YELLOWBG $BLACKFG "NOTICE  :$STATUS_MESSAGE"  ;;
	# Notifications of non-fatal errors , always viewable
	
	error) \
	printf "%s\n\a" "$DATE:ERROR:$STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;
	[ -n "$LOGLEVEL" ] &&
	printf $format $NOTBOLD $REDBG $YELLOWFG "ERROR   :$STATUS_MESSAGE"  ;;
	# Errors , always viewable

	verbose) \
	printf "%s\n" "$DATE:VERBOSE: $STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;
	[ "$LOGLEVEL" = "VERBOSE" ] &&
	printf $format $NOTBOLD $WHITEBG $BLACKFG "VERBOSE :$STATUS_MESSAGE" ;;
	# All verbose output
	
	header) \
	[ "$LOGLEVEL" = "VERBOSE" ] &&
	printf $format $NOTBOLD $BLUEBG $BLUEFG "VERBOSE :$STATUS_MESSAGE" ;
	printf "%s\n" "$DATE:PROGRESS: $STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;;
	# Function and section headers for the script
	
	passed) \
	[ "$LOGLEVEL" = "VERBOSE" ] &&
	printf $format $NOTBOLD $GREENBG $BLACKFG "SANITY  :$STATUS_MESSAGE" ;
	printf "%s\n" "$DATE:SANITY: $STATUS_MESSAGE" >> "${SCRIPTLOG:?}" ;;
	# Sanity checks and "good" information
	graphical) \
	[ "$GUI" = "ENABLED" ] &&
	showUIDialog "$STATUS_MESSAGE" ;;
	
esac
return 0
} # END statusMessage()


# Check script options
statusMessage header "GETOPTS: Processing script $# options:$@"
# ABOVE: Check to see if we are running as a postflight script,the installer  creates $SCRIPT_NAME
[ $# = 0 ] && statusMessage verbose "No options given"
# If we are not running postflight and no parameters given, print usage to stderr and exit status 1
while getopts vCu SWITCH ; do
        case $SWITCH in
                v ) export LOGLEVEL="VERBOSE" ;;
                C ) export ENABLECOLOR="YES" ;;
                u ) export GUI="ENABLED" ;;
        esac
done # END getopts

function mountNFS() {
	## Mount our volume over NFS if it isn't already mounted
    ## expects to be passed vars $NFSURI, which is standard host:path notation
    ## the second variable, $NFSMOUNTPOINT defines where the share will be mounted
    ## if $NFSMOUNTPOINT is not provided, then it will derive the name via the 
    ## full NFS path. For example: hax.lbc:/Shares/NFSshare 
    ## would mount at /Volumes/hax.lbc/Shares/NFSshare
        
    declare -x NFSURI="$1"
    declare -x NFSMOUNTPOINT="$2"

    declare -x awk="/usr/bin/awk"
    declare -x df="/bin/df"
    declare -x mount="/sbin/mount"
    declare -x grep="/usr/bin/grep"
    declare -x mkdir="/bin/mkdir"
    declare -x rm="/bin/rm"
    declare -x rmdir="/bin/rmdir"
    
    if [ -z "$NFSURI" ]; then
        statusMessage error "mountNFS() No hostname:/path provided!"
        return 1
    else 
        declare -x NFSSERVER="$(printf "$NFSURI" | awk -F: '{print$1}' )"
        declare -x NFSPATH="$(printf "$NFSURI" | awk -F: '{print$2}' )"
        if ([ -z "$NFSSERVER" ] || [ -z "$NFSPATH" ]); then
            statusMessage error "mountNFS() could not derive mount path from server URI: $NFSURI! NFSSERVER:$NFSSERVER NFSPATH:$NFSPATH"            
            return 1
        fi
    fi
    
    if [ -z "$NFSMOUNTPOINT" ]; then
        NFSMOUNTPOINT="/Volumes/$NFSSERVER/$NFSPATH"
    fi
    
    statusMessage progress "mountNFS() Mounting nfs://$NFSURI to $NFSMOUNTPOINT"
    "$df" | "$grep" -Eiq  "${NFSMOUNTPOINT}\$" &> /dev/null
    if [ $? != 0 ] ; then
        if [ -d "$NFSMOUNTPOINT" ]; then
            statusMessage notice "mountNFS() A local directory was found at mount point: $NFSMOUNTPOINT, attempting to remove"
            if [ -f "$NFSMOUNTPOINT"/.DS_Store ]; then
                "$rm" "$NFSMOUNTPOINT"/.DS_Store
            fi
            "$rmdir" "$NFSMOUNTPOINT" &> /dev/null || statusMessage notice "mountNFS() Local directory $NFSMOUNTPOINT, could not be removed, mounting NFS share in it's place."
        fi
        
        "$mkdir" -p "$NFSMOUNTPOINT" ##&> /dev/null
        sleep 1
        "$mount" "$NFSURI" "$NFSMOUNTPOINT"	
        mountResult=$?
        if [ $mountResult == 0 ]; then
            statusMessage verbose "mountNFS() - Successfully mounted share!"
        else
            statusMessage error "mountNFS() - Failed to mount $NFSURI to $NFSMOUNTPOINT, exiting!"
            return $mountResult 
        fi
    else
        statusMessage notice "mountNFS() - NFS Volume: $NFSURI already mounted at $NFSMOUNTPOINT!"
        return 99
    fi
    return 0
} # end mountNFS()

function mountAFP() {
	### Mount our volume over AFP if it isn't already mounted
    ## expects to be passed vars AFPSERVER, AFPSHARE, AFPUSER, AFPPASS
    ## If global variable AFPMOUNTPOINT is defined, or via fifth we will use that value
    ## otherwise we mount at /Volumes/AFPSHARE
    ## If you wish to use kerberos, and supply a nonstandard mount point,
    ## supply only the first three vars and set the global AFPMOUNTPOINT var

    declare -x AFPSERVER="$1"
    declare -x AFPSHARE="$2"	
    declare -x AFPUSER="$3"
    declare -x AFPPASS="$4"
    
    if [ -n "$5" ]; then
        declare -x AFPMOUNTPOINT="$5"    
    elif [ -n "$AFPMOUNTPOINT" ]; then
        declare -x AFPMOUNTPOINT="$AFPMOUNTPOINT"
    else 
        declare -x AFPMOUNTPOINT="/Volumes/$AFPSHARE"
    fi
 
    if ( [ -z "$AFPUSER" ] || [ -z "$AFPSERVER" ] || [ -z "$AFPSHARE" ] ); then
        statusMessage error "mountAFP() Not all information was supplied: expects to be passed vars AFPSERVER, AFPSHARE, AFPUSER, AFPPASS"
        return 5
    fi
    
    declare -x df="/bin/df"
    declare -x mount_afp="/sbin/mount_afp"
    declare -x grep="/usr/bin/grep"
    declare -x mkdir="/bin/mkdir"
    
    statusMessage progress "mountAFP() Mounting afp://$AFPSERVER/${AFPSHARE// /%20} to $AFPMOUNTPOINT"
    "$df" | "$grep" -Eiq "${AFPMOUNTPOINT}\$" &> /dev/null
	if [ $? != 0 ]; then
        if [ -d "$AFPMOUNTPOINT" ]; then
            statusMessage notice "mountAFP() A local directory was found at mount point: $AFPMOUNTPOINT, attempting to remove"
            if [ -f "$AFPMOUNTPOINT"/.DS_Store ]; then
                "$rm" "$AFPMOUNTPOINT"/.DS_Store
            fi
            "$rmdir" "$AFPMOUNTPOINT" &> /dev/null || statusMessage notice "mountAFP() Local directory $AFPMOUNTPOINT, could not be removed, mounting AFP share in it's place."
        fi
		"$mkdir" -p "${AFPMOUNTPOINT:?}" &> /dev/null
		if [ -n "$AFPPASS" ]; then
            "$mount_afp" -o nobrowse afp://${AFPUSER:?}:${AFPPASS:?}@${AFPSERVER:?}/${AFPSHARE// /%20} "${AFPMOUNTPOINT}"
            mountResult=$?
        else
            if [ "$(whoami)" == "root" ]; then
               "$mount_afp" -o nobrowse "afp://$AFPUSER;AUTH=Client%20Krb%20v2@${AFPSERVER:?}/${AFPSHARE// /%20}" "${AFPMOUNTPOINT}"            
                mountResult=$?
            else
                "$mount_afp" -o nobrowse "afp://$AFPUSER;AUTH=Client%20Krb%20v2@${AFPSERVER:?}/${AFPSHARE// /%20}" "${AFPMOUNTPOINT}"            
                mountResult=$?
            fi
        fi
        if [ $mountResult == 0 ]; then
            statusMessage verbose "mountAFP() - Successfully mounted share!"
        fi
        return $mountResult	
	else 
        statusMessage notice "mountAFP() - AFP Share: $AFPUSER@$AFPSERVER/${AFPSHARE// /%20} already mounted at $AFPMOUNTPOINT!"
        return 99
	fi
	return 0
} # end mountAFP()

function mountSMB() {
	### Mount our volume over SMB if it isn't already mounted
    ## expects to be passed vars SMBSERVER, SMBSHARE, SMBUSER, SMBPASS
    ## If global variable SMBMOUNTPOINT is defined, or via fifth we will use that value
    ## otherwise we mount at /Volumes/SMBSHARE

    declare -x SMBSERVER="$1"
    declare -x SMBSHARE="$2"	
    declare -x SMBUSER="$3"
    declare -x SMBPASS="$4"
    if [ -n "$5" ]; then
        declare -x SMBMOUNTPOINT="$5"    
    elif [ -n "$SMBMOUNTPOINT" ]; then
        declare -x SMBMOUNTPOINT="$SMBMOUNTPOINT"
    else 
        declare -x SMBMOUNTPOINT="/Volumes/$SMBSHARE"

    fi
 
    
    if ( [ -z "$SMBUSER" ] || [ -z "$SMBPASS" ] || [ -z "$SMBSERVER" ] || [ -z "$SMBSHARE" ] ); then
        statusMessage error "mountSMB() Not all information was supplied: expects to be passed vars SMBSERVER, SMBSHARE, SMBUSER, SMBPASS"
        return 5
    fi
    
    declare -x df="/bin/df"
    declare -x mount="/sbin/mount"
    declare -x grep="/usr/bin/grep"
    declare -x mkdir="/bin/mkdir"
    
    statusMessage progress "mountSMB() Mounting share:\\\\$SMBSERVER\\${SMBSHARE// /%20} to $SMBMOUNTPOINT"
    "$df" | "$grep" -Eiq  "${SMBMOUNTPOINT}\$" &> /dev/null
	if [ $? != 0 ]; then
        if [ -d "$SMBMOUNTPOINT" ]; then
            statusMessage notice "mountSMB() A local directory was found at mount point: $SMBMOUNTPOINT, attempting to remove"
            if [ -f "$SMBMOUNTPOINT"/.DS_Store ]; then
                "$rm" "$SMBMOUNTPOINT"/.DS_Store
            fi
            "$rmdir" "$SMBMOUNTPOINT" &> /dev/null || statusMessage notice "mountSMB() Local directory $SMBMOUNTPOINT, could not be removed, mounting SMB share in it's place."
        fi
		"$mkdir" -p "${SMBMOUNTPOINT:?}" &> /dev/null
		"$mount" -t smbfs -o nobrowse //${SMBUSER:?}:${SMBPASS:?}@${SMBSERVER:?}/${SMBSHARE// /%20} "${SMBMOUNTPOINT}"
        mountResult=$?
        if [ $mountResult == 0 ]; then
            statusMessage progress "mountSMB() - Successfully mounted share!"
        fi
        return $mountResult	
    else 
        statusMessage progress "mountSMB() - SMB Share: share:\\\\$SMBSERVER\\$SMBSHARE already mounted at $SMBMOUNTPOINT!"
        return 99
	fi
	return 0
} # end mountSMB()

function unmountVolume() {
	## Accepts a single argument, PATH, and unmounts any network mounts found
    ## at that directory. If after 3 attempts, this fails, a force unmount will
    ## be attempted.

    if [ -n "$1" ]; then
        MOUNTPOINT=$1
    else 
        statusMessage error "unmountVolume() Not provided mountpoint!"
        return 2
    fi
    
    declare -x df="/bin/df"
    declare -x diskutil="/usr/sbin/diskutil"
    declare -x hdiutil="/usr/bin/hdiutil"
    declare -x grep="/usr/bin/grep"
    declare -x sleep="/bin/sleep"
    declare -x umount="/sbin/umount"

    ##statusMessage verbose "unmountVolume() Unmounting volume: $MOUNTPOINT!"
    
    COUNT=0
    while [ "$("$df" | "$grep" -Eic  "${MOUNTPOINT}\$")" -ge 1 ]; do 
        let COUNT++
        if [ $COUNT -le 10 ]; then
            statusMessage verbose "unmountVolume() Unmounting volume: $MOUNTPOINT (attempt $COUNT of 10)"
            "$hdiutil" detach "$MOUNTPOINT" >> "$SCRIPTLOG"
        elif [ $COUNT -eq 11 ]; then
            statusMessage notice "unmountVolume() volume: $MOUNTPOINT failed to unmount, forcing!"
            "$diskutil" unmount force "$MOUNTPOINT" >> "$SCRIPTLOG"
        else
            statusMessage error "backupServerAdmin() volume failed to unmount!"
            exit 1
        fi
        "$sleep" 1
    done
    
    return 0

} # end unmountVolume()

function backupServerAdmin() {
	## Backup ServerAdmin settings. This is done via a sparse disk image
    ## expects to be passed vars BACKUPDIR, DMGNAME, DMGMOUNTPOINT
    ## If global variable SABACKUPDMG or SABACKUPMOUNTPOINT ar defined,
    ## they do will be used if respective arguments are not passed.
    ## Backs up server admin settings via serveradmin settings all,
    ## Generates 
    
    if [ -n "$1" ]; then
        declare -x BACKUPDIR="$1"
    else
        declare -x BACKUPDIR="$BACKUPDIR"
    fi
    if [ -n "$2" ]; then
        declare -x DMGNAME="$2"
    else
        declare -x DMGNAME="$SABACKUPDMG"
    fi
    if [ -n "$3" ]; then
        declare -x DMGMOUNTPOINT="$3"
    else 
        declare -x DMGMOUNTPOINT="$SABACKUPMOUNTPOINT"
    fi
    
    declare -x DMGPATH="${BACKUPDIR}/${DMGNAME}"

    declare -x diff="/usr/bin/diff"
    declare -x grep="/usr/bin/grep"
    declare -x hdiutil="/usr/bin/hdiutil"  
    declare -x ln="/bin/ln"
    declare -x mv="/bin/mv"    
    declare -x mkdir="/bin/mkdir"
    declare -x mktemp="/usr/bin/mktemp"
    declare -x rm="/bin/rm"
    declare -x rmdir="/bin/rmdir"  
    declare -x serveradmin="/usr/sbin/serveradmin" 
    declare -x umount="/sbin/umount"

    ## Sanity checks
    if [ ! -d "${BACKUPDIR}" ]; then
        statusMessage verbose "backupServerAdmin() Creating backup directory: $BACKUPDIR"
        "$mkdir" -p "$BACKUPDIR" &> /dev/null
        mkdirResult=$?
        if [ $? != 0 ]; then
            statusMessage error "backupServerAdmin() Could not create directory: error: $mkdirResult "
        fi
    fi
    
    if ( [ -z "$BACKUPDIR" ] || [ -z "$DMGMOUNTPOINT" ] || [ -z "$DMGNAME" ] ); then
        statusMessage error "backupServerAdmin() Supplied incomplete information need: BACKUPDIR DMGNAME DMGMOUNTPOINT"
        return 5
    fi
    
    ## Check for directory mounted where our DMG should be mounted
    if [ -d "$DMGMOUNTPOINT" ]; then
        statusMessage error "backupServerAdmin() Directory mounted at ServerAdmin Backup DMG mountpath: $DMGMOUNTPOINT"
        "$umount" "$DMGMOUNTPOINT"
        "$rm" "$DMGMOUNTPOINT"/.DS_Store &> /dev/null
        "$rmdir" "$DMGMOUNTPOINT" &> /dev/null
        if [ -d "$DMGMOUNTPOINT" ]; then
            statusMessage error "backupServerAdmin() Could not resolve the issue, please remove: $DMGMOUNTPOINT"	
            exit 4
        fi 
    fi

    TEMPPATH="$("$mktemp" -d /tmp/sabackup_XXXXXX)"

    ## Check for an archive disk image
    if [ -d "${DMGPATH:?}" ]; then
        "$hdiutil" mount -nobrowse "$DMGPATH" >> "$SCRIPTLOG"
        statusMessage verbose "backupServerAdmin() ServerAdmin Backup DMG found, mounting!"
    else
        statusMessage progress "backupServerAdmin() ServerAdmin Backup DMG: $DMGNAME could not be found! creating..."
        ## here if we need to create our DMG
        "$hdiutil" create -type SPARSEBUNDLE -size 1g -fs HFS+ -volname "${DMGNAME%.sparsebundle}" "$TEMPPATH"/"$DMGNAME" >> "$SCRIPTLOG"
        "$mv" "$TEMPPATH"/"$DMGNAME" "$DMGPATH"
        if [ $? != 0 ]; then
            statusMessage error "backupServerAdmin() Could not move from $TEMPPATH/$DMGNAME"
            exit 3
        fi
        "$hdiutil" mount -nobrowse "$DMGPATH" >> "$SCRIPTLOG"
        statusMessage progress "backupServerAdmin() Mounting ServerAdmin Backup DMG"
    fi


    ## One last sanity check
    if [ ! -d "$DMGMOUNTPOINT" ]; then
        statusMessage error "backupServerAdmin() Disk image did not seem to mount! Exiting!"
        exit 5
    fi

    ## and last but not least, dump our settings
    statusMessage progress "backupServerAdmin() Checking for changes..." 
    "$serveradmin" settings all | "$grep" -v "info:currentTime" > "$TEMPPATH"/sa_export_"$DATE".txt

    "$diff" "$DMGMOUNTPOINT"/latest.txt "$TEMPPATH"/"sa_export_$DATE.txt" &> /dev/null
    if [ $? == 0 ]; then
        statusMessage progress "backupServerAdmin() No changes were detected, not saving export" 
    else
        statusMessage notice "backupServerAdmin() Changes found, saving output and creating diff file." 
        "$diff" "$DMGMOUNTPOINT"/latest.txt "$TEMPPATH"/"sa_export_$DATE.txt" >> "$DMGMOUNTPOINT"/"sa_export_${DATE}-diff.txt" 
        "$mv" -f "$TEMPPATH"/sa_export_"$DATE".txt "$DMGMOUNTPOINT"/"sa_export_$DATE.txt"	
        cd "$DMGMOUNTPOINT"
        if [ -L "latest.txt" ]; then
            statusMessage progress "backupServerAdmin() updating latest.txt" 
            "$rm" "latest.txt"
        fi
        "$ln" -s "sa_export_$DATE.txt" "latest.txt"
        cd "$OLDPWD"
    fi


    if [ -d "$TEMPPATH" ]; then
        statusMessage progress "backupServerAdmin() removing temporary path: $TEMPPATH" 
        "$rm" -rf "$TEMPPATH" &> /dev/null
    fi

    statusMessage progress "backupServerAdmin() Backup completed, unmounting DMG" 
    unmountVolume "$DMGMOUNTPOINT"
    return 0
} # end backupServerAdmin()


#######################################################
#                                                     #
#################### MAIN #############################
#######################################################
#######################################################
#######################################################

exitCode=0
## If we aren't using a local destination, check to make sure our backup dir is mounted, abort otherwise
if [ "$(echo "$BACKUPDEST" | "$grep" -ci "afp")" -ge 1 ]; then
    statusMessage progress "Backing up via AFP to: $AFPSERVER/$AFPSHARE"
    mountAFP "$AFPSERVER" "$AFPSHARE" "$AFPUSER" "$AFPPASS" 
    mountResult=$?
    if ( [ "$mountResult" != 0 ] && [ "$mountResult" != 99 ]); then
        statusMessage error "Failed to mount sharepoint, errorCode: $mountResult"
        exitCode=$mountResult
        backupResults=$exitCode
    else
        backupServerAdmin "${AFPMOUNTPOINT:?}/${BACKUPDIR:?}" "$SABACKUPDMG" "$SABACKUPMOUNTPOINT"
        backupResults=$?
    fi
    if ([ $backupResults == 0 ] && ([ $mountResult == 0 ]|| [ $mountResult == 99 ])); then
        statusMessage progress "Backup to AFP completed successfully"
    else
        statusMessage error "Backup to AFP encountered error code: $backupResults"
        exitCode="$backupResults"
    fi
    if [ "$mountResult" != 99 ]; then
        unmountVolume "$AFPMOUNTPOINT"
    fi
fi
if [ "$(echo "$BACKUPDEST" | "$grep" -ci "smb")" -ge 1 ]; then
    statusMessage progress "Backing up via SMB to: $SMBSERVER/$SMBSHARE"
    mountSMB "$SMBSERVER" "$SMBSHARE" "$SMBUSER" "$SMBPASS"
    mountResult=$?
    if ( [ "$mountResult" != 0 ] && [ "$mountResult" != 99 ]); then
        statusMessage error "Failed to mount sharepoint, errorCode: $mountResult"
        exitCode=$mountResult
        backupResults=$exitCode
    else
        backupServerAdmin "${SMBMOUNTPOINT:?}/${BACKUPDIR:?}" "$SABACKUPDMG" "$SABACKUPMOUNTPOINT"
        backupResults=$?
    fi
    if ([ $backupResults == 0 ] && ([ $mountResult == 0 ]|| [ $mountResult == 99 ])); then
        statusMessage progress "Backup to SMB completed successfully"
    else
        statusMessage error "Backup to SMB encountered error code: $backupResults"
        exitCode="$backupResults"

    fi
    if [ "$mountResult" != 99 ]; then
        unmountVolume "$SMBMOUNTPOINT"
    fi
fi
if [ "$(echo "$BACKUPDEST" | "$grep" -ci "nfs")" -ge 1 ]; then
    statusMessage progress "Backing up via NFS to: $NFSURI"
    mountNFS "$NFSURI" "$NFSMOUNTPOINT"
    mountResult=$?
    if ( [ "$mountResult" != 0 ] && [ "$mountResult" != 99 ]); then
        statusMessage error "Failed to mount sharepoint, errorCode: $mountResult"
        exitCode=$mountResult
        backupResults=$exitCode
    else
        backupServerAdmin "${NFSMOUNTPOINT:?}/${BACKUPDIR:?}" "$SABACKUPDMG" "$SABACKUPMOUNTPOINT"
        backupResults=$?
    fi
    if ([ $backupResults == 0 ] && ([ $mountResult == 0 ]|| [ $mountResult == 99 ])); then
        statusMessage progress "Backup to NFS completed successfully"
    else
        statusMessage error "Backup to NFS encountered error code: $backupResults mountCode: $mountResult"
        exitCode="$backupResults"
    fi
    if [ "$mountResult" != 99 ]; then
        unmountVolume "$NFSMOUNTPOINT"
    fi
fi
if [ "$(echo "$BACKUPDEST" | "$grep" -ci "local")" -ge 1 ]; then
    statusMessage progress "Backing up to local directory: $BACKUPDIR"
    backupServerAdmin "${BACKUPDIR:?}" "$SABACKUPDMG" "$SABACKUPMOUNTPOINT"
    backupResults=$?
    if [ $backupResults == 0 ]; then
        statusMessage progress "Backup to local directory completed successfully"
    else
        statusMessage error "Backup to local directory encountered error code: $backupResults"
        exitCode="$backupResults"
    fi
fi

if [ $exitCode != 0 ]; then
    statusMessage error "One or all of the Backups reported failure errorCode: $backupResults"
else
    statusMessage notice "All Backups Completed Successfully!"
fi

exit $exitCode
