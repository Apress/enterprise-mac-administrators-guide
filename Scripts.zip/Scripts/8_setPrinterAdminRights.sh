#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin

## only members of the following group will be givent printer admin rights
declare -x printAdminGroup="staff"   

## modifies cupsd.conf to NOT require admin group membership to add printers,
## mainly needed for early versions of 10.5 where the equivalent MCX function 
## was unstable.
declare -x modifyCupsdDotConf=false 


###### script usage vars, should need to make changes  beyond this point. ######


declare -x theDate=`date +'%m%d%y'`
declare -x version="20090721_20:03"
declare -x scriptTag="setPrinterAdminRights"

logger -s -t "$scriptTag" "Executing $0 v.$version..."


### Add printer admin  ###

## Make sure an admin group was specified
if [ -z "$printAdminGroup" ]; then	
	logger -s -t "$scriptTag" "ERROR: No print admin group specified, exiting!"
	exit 1
fi

## Add specified admin group to local lpadmin group
logger -s -t "$scriptTag" "Adding $printAdminGroup to lpadmin group."
dseditgroup -o edit -a "$printAdminGroup" -t group lpadmin
addMemberReturnCode=$?
if [ $addMemberReturnCode == 0 ]; then
	logger -s -t "$scriptTag" "Successfully added $printAdminGroup to lpadmin"
else
	logger -s -t "$scriptTag" "Failed to add $printAdminGroup to lpadmin, returnCode: $addMemberReturnCode"
fi


## modify our cupsd.conf file if applicable, this gives lpadmin permissions to add/modify printers
if [ ${modifyCupsdDotConf:?} == "true" ]; then
	logger -s -t "$scriptTag" "Granting group lpadmin rights to add printers in cupsd.conf!"
	perl -00pe 's/(<Limit CUPS-Add-Modify-Printer.*?)(AuthType.*)(Require user)( \@SYSTEM$)(.*?<\/Limit>)/$1$3 \@SYSTEM \@lpadmin$5/ms' -i /etc/cups/cupsd.conf
else
	logger -s -t "$scriptTag" "cupsd.conf not being touched"
	killall cupsd
fi
