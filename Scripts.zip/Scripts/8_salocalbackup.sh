#!/bin/bash

##########  Server Admin Backup Script #####################
##
##	Written by Beau Hunter, Zack Smith  7/03/09
##  beauh@mac.com acid@wallcity.org
##  Server Admin backup script, equivallent to serveradmin settings all
##  backs up only when config changes, generates diffs with each change.
##
###############################################################################

## User configuration
SABACKUPDIR=/Auto\ Server\ Setup

## Serveradmin archive disk image
SAARCHIVEDMG="serveradmin_archives.sparsebundle"
SAARCHIVE_MOUNTPOINT="/Volumes/${SAARCHIVEDMG%.sparsebundle}"

## bin vars
declare -x grep="/usr/bin/grep"
declare -x serveradmin="/usr/sbin/serveradmin"
declare -x defaults="/usr/bin/defaults"
declare -x hdiutil="/usr/bin/hdiutil"
declare -x diskutil="/usr/sbin/diskutil"
declare -x mkdir="/bin/mkdir"
declare -x du="/usr/bin/du"
declare -x date="/bin/date"
declare -x diff="/usr/bin/diff"
declare -x awk="/usr/bin/awk"
declare -x mv="/bin/mv"
declare -x ln="/bin/ln"
declare -x mktemp="/usr/bin/mktemp"
declare -x umount="/sbin/umount"
declare -x sleep="/bin/sleep"

##  Runtime varibles
DATE=$("$date" +'%Y%m%d.%H%M_%S')
declare -x REQCMDS="$awk,$ntpdate,$perl,$scutil"
declare -x SCRIPT="${0##*/}" ; SCRIPTNAME="${SCRIPT%%\.*}"
declare -x SCRIPTPATH="$0" RUNDIRECTORY="${0%/*}"
declare -x SCRIPTLOG="/Library/Logs/${SCRIPT%%\.*}.log"

## test for root
[ "$EUID" != 0 ] && printf "%s\n" "This script requires root access ($EUID)!" && exit 1


exec 2>>"${SCRIPTLOG:?}" # Redirect standard error to log file


########## MAIN ##########

## check for the backup dir
if [ ! -d "$SABACKUPDIR" ]; then
	echo "A local directory was not found at path: $SABACKUPDIR, attempting to create"

	"$mkdir" "$SABACKUPDIR" &> /dev/null
	if [ $? != 0 ]; then
		echo "Failed to mount $NFSPATH to $SABACKUPDIR, exiting!"
		exit 1
	fi
fi

## Check for directory mounted where our DMG should be
if [ -d "$SAARCHIVE_MOUNTPOINT" ]; then
	echo "Directory mounted at ServerAdmin Backup DMG mountpath: $SAARCHIVE_MOUNTPOINT"
	"$umount" "$SAARCHIVE_MOUNTPOINT"

	## attempt to remove the local directory
	rm "$SAARCHIVE_MOUNTPOINT"/.DS_Store &> /dev/null
	rmdir "$SAARCHIVE_MOUNTPOINT" &> /dev/null
	if [ -d "$SAARCHIVE_MOUNTPOINT" ]; then
		echo "Could not resolve the issue, please remove: $SAARCHIVE_MOUNTPOINT"	
		exit 4
	fi 
fi

## Check for an archive disk image
if [ -d "$SABACKUPDIR"/"$SAARCHIVEDMG" ]; then
	## mount it if it exists
	"$hdiutil" mount -nobrowse "$SABACKUPDIR"/"$SAARCHIVEDMG" >> "$SCRIPTLOG"
	echo "ServerAdmin Backup DMG found, mounting!"
else
	## here if we need to create our DMG
	echo "ServerAdmin Backup DMG: $SAARCHIVEDMG could not be found! creating..."
	TEMPPATH="$("$mktemp" -d /tmp/XXXXXX)"
	"$hdiutil" create -type SPARSEBUNDLE -size 1g -fs HFS+ -volname "${SAARCHIVEDMG%.sparsebundle}" "$TEMPPATH"/"$SAARCHIVEDMG" >> "$SCRIPTLOG"
	"$mv" "$TEMPPATH"/"$SAARCHIVEDMG" "$SABACKUPDIR"/"$SAARCHIVEDMG"
	if [ $? != 0 ]; then
		echo "Could not move from $TEMPPATH/$SAARCHIVEDMG"
		exit 3
	fi
	"$hdiutil" mount -nobrowse "$SABACKUPDIR"/"$SAARCHIVEDMG" >> "$SCRIPTLOG"
	echo "Mounting ServerAdmin Backup DMG"
fi


## One last sanity check
if [ ! -d "$SAARCHIVE_MOUNTPOINT" ]; then
	echo "Disk image did not seem to mount! Exiting!"
	exit 5
fi

## and last but not least, dump our settings
echo "Checking for changes..." 
"$serveradmin" settings all | "$grep" -v "info:currentTime" > "$TEMPPATH"/sa_export_"$DATE".txt

"$diff" "$SAARCHIVE_MOUNTPOINT"/latest.txt "$TEMPPATH"/"sa_export_$DATE.txt" &> /dev/null
if [ $? == 0 ]; then
	echo "No changes were detected, not saving export" 
else
	echo "Changes found, saving output and creating diff file." 
	"$diff" "$SAARCHIVE_MOUNTPOINT"/latest.txt "$TEMPPATH"/"sa_export_$DATE.txt" >> "$SAARCHIVE_MOUNTPOINT"/"sa_export_${DATE}-diff.txt" 
	"$mv" -f "$TEMPPATH"/sa_export_"$DATE".txt "$SAARCHIVE_MOUNTPOINT"/"sa_export_$DATE.txt"	
	cd "$SAARCHIVE_MOUNTPOINT"
	"$ln" -s "sa_export_$DATE.txt" "latest.txt"
	cd "$OLDPWD"
fi


if [ -d "$TEMPPATH" ]; then
	"$rm" -rf "$TEMPPATH" &> /dev/null
fi

## if we're still here, then force the unmount (there is no messing around!)
while [ -d "$SAARCHIVE_MOUNTPOINT" ]; do 
	let COUNT++
	if [ $COUNT -le 10 ]; then
		echo "Unmounting ServerAdmin Backup DMG: $SAARCHIVE_MOUNTPOINT"
		"$hdiutil" eject "$SAARCHIVE_MOUNTPOINT" >> "$SCRIPTLOG"
	elif [ $COUNT -eq 11 ]; then
		echo "ServerAdmin Backup DMG failed to unmount, forcing!"
		"$diskutil" unmount force "$SAARCHIVE_MOUNTPOINT" >> "$SCRIPTLOG"
	else
		echo "ServerAdmin Backup DMG failed to unmount!"
                break
	fi
	"$sleep" 1
done

exit 0
