#!/bin/bash

############################
##
## Local Permissioning script for setting local administrative groups 
## for system and ARD admin access. Compatable with 10.5, and 10.6
## Uses dseditgroup to modify the active systems group membership. As
## Such, it can only operate on the active system volume.
##
## Written by Beau Hunter 
## 04/04/09   beauh@mac.com
##
########################################################

declare -x version=08310901
export PATH="/usr/bin:/bin:/usr/sbin:/sbin"

## vars
## localAdminGroup: specify network group to provide local admin access to
declare -x localAdminGroup="od_desktopadmins"

## setupLocalARDGroups: if '1', ard access groups
## will be created in local Directory Services
declare -x -i setupLocalARDGroups=1

## resetARD: if '1', ARD access will be configured
declare -x -i configARD=1

## resetARD: if '1', all ARD access privileges will be reset
declare -x -i resetARD=1

## ardAdminUser: the specified user will be have ARD admin access
declare -x ardAdminUser="hax_admin"

## ardAdminGroup: the specified group will be given ARD admin access
declare -x ardAdminGroup="mobo"

## ardInteractGroup: the specified group will be given ARD interact access
declare -x ardInteractGroup="monitors"


## static and system vars
declare -x scriptName=setNetworkAdminRights
declare -x theDate=$(date +'%Y%m%d')
declare -x -i isTiger="$(sw_vers | grep -c 10.4)"
declare -x -i isLeopard="$(sw_vers | grep -c 10.5)"
declare -x -i isSnowLeopard="$(sw_vers | grep -c 10.6)"
declare -x ARDVersion="$(defaults read /System/Library/CoreServices/RemoteManagement/ARDAgent.app/Contents/Info CFBundleShortVersionString)"
declare -x -i ARDMajorVersion="$(echo "$ARDVersion" | awk -F. '{print $1}')"
declare -x -i ARDMinorVersion="$(echo "$ARDVersion" | awk -F. '{print $2}')"


function getGUIDforGroup() {
    ## outputs a GUID for passed group name
    declare -x theGroupName="$1"
    declare -x GUID="$(/usr/bin/dscl /Search read /Groups/"$theGroupName" GeneratedUID | awk '{print $2}')"
    if [ ! -z "$GUID" ]; then        
        echo $GUID
    else
        logger -s -t "$scriptName" "Error! Could not determine GUID for group \"$theGroupName\""
        return 1
    fi
    return 0
}


if [ "$USER" != root ]; then
    echo "Must run as root user, exiting!!"
    exit 1
fi


if [ ! -z "$localAdminGroup" ]; then
	GUID=$(getGUIDforGroup "$localAdminGroup")
    if [ $? == 0 ]; then        
        logger -s -t "$scriptName" "Nesting Directory Group: $localAdminGroup into local Group: admin"
        /usr/sbin/dseditgroup -o edit -a "${localAdminGroup:?}" -t group admin
    else
        logger -s -t "$scriptName" "Error! Could not determine GUID for group \"$localAdminGroup\""
    fi
fi

if [ $configARD -eq 1 ]; then
		if [ $setupLocalARDGroups -eq 1 ]; then
            if [ "$isSnowLeopard" -ge 1 ]; then
                ardAdminLocalGroup="com.apple.local.ard_admin"
                ardInteractLocalGroup="com.apple.local.ard_interact"
            else
                ardAdminLocalGroup="ard_admin"
                ardInteractLocalGroup="ard_interact"
            fi 
		else 
        	ardAdminLocalGroup=$ardAdminGroup
            ardInteractLocalGroup=$ardInteractGroup
        fi

    ## Process our Admin Group
    if [ ! -z "$ardAdminGroup" ]; then
        GUID=$(getGUIDforGroup "$ardAdminGroup")
        if [ $? == 0 ]; then        
	    	if [ $setupLocalARDGroups -eq 1 ]; then
                logger -s -t "$scriptName" "Nesting Directory Group: $ardAdminGroup into local Group: $ardAdminLocalGroup"
            	/usr/bin/dscl . read /Groups/$ardAdminLocalGroup &> /dev/null || /usr/sbin/dseditgroup -o create -i 115 -g 2806364B-49F6-4F18-89F9-D159BB93B08C $ardAdminLocalGroup 
            	/usr/sbin/dseditgroup -o edit -a "${ardAdminGroup:?}" -t group $ardAdminLocalGroup
            fi
        else
            logger -s -t "$scriptName" "Error! Failed to create Local ARD Admin Group: $ardAdminLocalGroup"
            errorCode=1
        fi            
    fi
    ## Process our Interact Group
    if [ ! -z "$ardInteractGroup" ]; then
        GUID=$(getGUIDforGroup "$ardInteractGroup")
        if [ $? == 0 ]; then  
            if [ $setupLocalARDGroups -eq 1 ]; then
	            logger -s -t "$scriptName" "Nesting Directory Group: $ardInteractGroup into local Group:$ardInteractLocalGroup"
    	        /usr/bin/dscl . read /Groups/"$ardInteractLocalGroup" &> /dev/null || /usr/sbin/dseditgroup -o create -i 116 -g 2806364B-49F6-4F18-89F9-D159BB93B08D "$ardInteractLocalGroup"
        	    /usr/sbin/dseditgroup -o edit -a "$ardInteractGroup" -t group "$ardInteractLocalGroup"
        	else
            	ardInteractLocalGroup=$ardInteractGroup
            fi
        else
            logger -s -t "$scriptName" "Error! Failed to create Local ARD Interact Group"
            errorCode=2
        fi            
    fi
    ## Process our kickstart commands
    kickstart="/System/Library/CoreServices/RemoteManagement/ARDAgent.app/Contents/Resources/kickstart"
    if [ $resetARD -eq 1 ]; then
            logger -s -t "$scriptName" "Ressetting ARD permissions"
            "$kickstart" -uninstall -settings
            "$kickstart" -configure -access -off
    fi
    if [ ! -z "$ardAdminUser" ]; then
        id "$ardAdminUser" &> /dev/null
        if [ $? == 0 ]; then
            logger -s -t "$scriptName" "Setting ARD access for user \"$ardAdminUser\""
            "$kickstart" -configure -access -on -users "$ardAdminUser" -privs -all
        else
            logger -s -t "$scriptName" "Could not resolve user \"$ardAdminUser\""
            errorCode=3
        fi
    fi
    
    ## reset Directory Services and flush cache
    /usr/bin/dscacheutil -flushcache
    /usr/bin/killall DirectoryService
    sleep 2
    id &> /dev/null
    
    if ( [ ! -z "$ardAdminGroup" ] && [ ! -z "$ardInteractGroup" ] ); then
        logger -s -t "$scriptName" "Setting ARD access for groups $ardAdminLocalGroup,$ardInteractLocalGroup"
    elif [ ! -z "$ardAdminGroup" ]; then
        logger -s -t "$scriptName" "Setting ARD access for groups $ardAdminLocalGroup"
    elif [ ! -z "$ardInteractGroup" ]; then
        logger -s -t "$scriptName" "Setting ARD access for groups $ardInteractLocalGroup"
    fi
    if ( [ $ARDMajorVersion -eq 3 ] && [ $ARDMinorVersion -ge 3 ]); then
    	logger -s -t "$scriptName" "Kickstart -configure -clientopts -setdirlogins -dirlogins yes -restart -agent"
    	"$kickstart" -configure -clientopts -setdirlogins -dirlogins yes -restart -agent
    elif ( [ $ARDMajorVersion -eq 3 ] ) ; then
        logger -s -t "$scriptName" "Kickstart -configure -clientopts -setdirlogins -dirlogins yes -setdirgroups -dirgroups $ardAdminLocalGroup,$ardInteractLocalGroup -restart -agent"
    	"$kickstart" -configure -clientopts -setdirlogins -dirlogins yes -setdirgroups -dirgroups $ardAdminLocalGroup,$ardInteractLocalGroup -restart -agent
	else
		logger -s -t "$scriptName" "ARD Version: $ARDVersion not supported!"
		exit 5
	fi
fi

