#!/bin/sh

##########  Home Directory Privilege Repair Script #####################
##  Written by Beau Hunter  08/22/08
##  beauh@mac.com
##  
##  Script which automates the management of home directory permissions
##  It's typical usage is to ensure proper permissions on every user's
##  home directory. That is, mode 700 to all home folders except ~/Public 
##  and ~/Sites. Additionally, if useACLs is set to true, then ACE's will
##  be pushed to each home directory for it's respective user. 
##
##  On top of this, you can specify global admin groups via the aclGroups
##  variable, in addition to a permission set to apply to each group.
##
##  The tool can be used to cleanup stale home
##  folders for non-existent users by placing the homes in an orphanage
##  folder.
##
##########################################################################

PATH=/bin:/sbin:/usr/bin:/usr/sbin

## homeDirectories: Comma separated list of home roots, specify the 
## depth via a colon. For instance, a standard 
## OS X local home folder has user homes directly in
## /Users, thus I could specify a homeLoc of 
## /Users:0. However, a depth of 0 is the default
## depth so it can be ommitted. 
declare -x homeDirectories="/testUsers:1"

declare -x repairPrivs=true
declare -x removeACLs=true
declare -x useACLs=true

  
## $aclGroups Groups sets an inherited ACL across $homeLoc, groups should be 
## comma delmited. Access levels can be delimited with a colon, 
## supported values are: "fc", "rw", and "ro". Default is rw. 
## Example:
## aclGroups="admin:fc,powerusers:rw,rousers:ro"

declare -x aclGroups="admin:fc,staff:rw"
declare -x removeOrphans=true	## Remove non-user directories from the path.
declare -x orphanageName="orphanage" ## the name of the orphanage folder


#### int script vars, probably don't need to make changes beyond this point #### 

declare -x date=`date +'%m%d%y'`
declare -x version="20080822_12:03"
declare -x scriptTag="$(basename "$0")"

logger -s -t "$scriptTag" "Executing script: $scriptTag v.$version"


function repairPrivs() {
	## repair privileges on all items in a particular home folder
	## expects home profiles based on users shortname. 
	## if the directory name is not resolvable as a user, we skip
	## A directory path can be passed as a variable, otherwise 
    ## executes based on PWD

    declare -x scriptTag="$scriptTag:repairPrivs()"


    if [ -n "$1" ]; then
        declare -x passedDirectory=$1
        if [ -d "$passedDirectory" ]; then
            cd "$passedDirectory"
        else
            logger -s -t "$scriptTag" "structureForOSX() passed directory: \"$passedDirectory\" does not exist!"
            return 1
        fi
    fi

	logger -s -t "$scriptTag" "Validating users in \"$(pwd)\" for priviledge repair" 

	IFS=$'\n'
	for fileObject in `ls | grep -v .DS_Store | grep -v "$orphanageName" | egrep -v '^\.'`; do
		#logger -s -t "$scriptTag" "Validating $fileObject for priviledge repair" 
		id "$fileObject" &> /dev/null
		if [ $? == 0 ]; then
			#logger -s -t "$scriptTag" " - validation passed, changing permissions for $fileObject at `pwd`/$fileObject"
			logger -s -t "$scriptTag" " Validation passed for $fileObject, changing permissions"

		else
			logger -s -t "$scriptTag" " Validation failed for '$fileObject', it is an orphan "

			## get our pwd and get our current directory. We 
			## mimic our structure in the orphanage, this script
			## needs more facilities to handle depth properly.

			declare -x PWD="$(pwd)"
            
            if [ "$homeDepth" == 0 ]; then
                declare -x orphanDir="$homeLoc/$orphanageName"
            else 
                declare -x orphanDir="$homeLoc/$orphanageName/$(basename "$PWD")"
            fi

			if [ "$removeOrphans" == true ]; then
				logger -s -t "$scriptTag" " - Placing $fileObject in orphanage:$orphanDir!"
				if [ ! -d "${orphanDir:?}" ]; then
					mkdir -p "${orphanDir:?}"
					if [ $? != 0 ]; then
					 	logger -s -t "$scriptTag" "  - ERROR: Could not create $orphanDir, not moving!"
						continue
					fi
				fi	

				mv "$fileObject" ${orphanDir:?}/					
				if [ $? != 0 ]; then
					logger -s -t "$scriptTag" "  - ERROR: Could not move user home \"$fileObject\" to orphanage!"
				fi            
			fi
			continue
		fi

		#echo chown -R "$fileObject":admin "$fileObject"
		chown -f -R "$fileObject":admin "$fileObject"
		if [ ${removeACLs:?} == "true" ]; then
			#logger -s -t "$scriptTag" "  - removing ACL's"
			chmod -f -R -N "$fileObject"
		fi

		## Apply ACLs to the user dir, we do an explicit ACE at the user's home 
		## and then apply inherited ACLs to children. 
		if [ ${useACLs:?} == "true" ]; then
			logger -s -t "$scriptTag" "  - applying user ACL's"
			chmod +a "$fileObject:allow:list,add_file,search,delete,add_subdirectory,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,writesecurity,chown,file_inherit,directory_inherit" "$fileObject"
			chmod -f -R +ai "$fileObject:allow:list,add_file,search,delete,add_subdirectory,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,writesecurity,chown,file_inherit,directory_inherit" "$fileObject"/* 
		fi
		
		chmod 755 "$fileObject"
		chmod -R 700 "$fileObject"/*
		if [ -d "$fileObject"/Sites ]; then
			chmod -R 775 "$fileObject"/Sites
		fi
		if [ -d "$fileObject"/Public ]; then	
			chmod -R 775 "$fileObject"/Public
			chmod -R 773 "$fileObject"/Public/Drop\ Box
		fi
	done
    ## if we were passed a directory, traverse out of it
    if [ -n "$passedDirectory" ]; then
        cd "$OLDPWD"
    fi
}  ## end repairPrivs()

function setACLForGroup() {
	## passes $directory as first argument, $group as second argument, and $permissions 
	## this sets an explicit ACL at $directory, with all children receiving an 'inherited' ACL
	## we accept several different permission types:
    ## "fc"(Full Control)
    ## "rw" (Read and Write)
    ## "ro" (Read Only)
    ## "append" (Append Only)

	declare -x directory=$1
	declare -x group=$2
	declare -x permissions=$3
    declare -x scriptTag="$scriptTag:setACLForGroup()"
    
    logger -s -t "$scriptTag" "Attempting to apply: ACL to dir:$directory for group:$group with perms:$permissions"

    
	## sanity check our directory
	if [ ! -d "$directory" ]; then
		logger -s -t "$scriptTag" " - ERROR: Could not apply ACL.. dir:$directory does not exist!"
		return 1
	fi	

	## sanity check our group
	dscl /Search read /Groups/"$group" name &> /dev/null
	dsclCode=$?
	if [ $dsclCode != 0 ]; then
		logger -s -t "$scriptTag" " - ERROR: could not apply ACL.. group:$group does not exist! dscl code: $dsclCode"
		return 2
	fi	

	## sanity check our permissions
	##if ( [ "$permissions" != "fc" ] && [ "$permissions" != "rw" ] && [ "$permissions" != "ro" ] ); then
	##	logger -s -t "$scriptTag" "setACLForGroup() could not apply ACL.. permissions:$permissions invalid, use 'fc'(Full Control), 'rw' (Read and Write), 'ro' (Read Only)!"
	##	return 3
	##fi   
	
	## deploy our ACL's
	case "$permissions" in
        fc) ace="allow:list,add_file,search,delete,add_subdirectory,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,writesecurity,chown,file_inherit,directory_inherit";;
        rw) ace="allow:list,add_file,search,delete,add_subdirectory,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,file_inherit,directory_inherit";;
        append) ace="allow:list,add_file,search,add_subdirectory,readattr,writeattr,readextattr,writeextattr,readsecurity,file_inherit,directory_inherit";;
        ro) ace="allow:list,search,readattr,readextattr,readsecurity,file_inherit,directory_inherit";;
        *)  logger -s -t "$scriptTag" "setACLForGroup() could not apply ACL.. permissions:$permissions invalid!! defaulting to 'ro' (Read Only)!"
            ace="allow:list,search,readattr,readextattr,readsecurity,file_inherit,directory_inherit"
            permissions="ro"
        ;;
    esac

	logger -s -t "$scriptTag" " - applying ACL to dir:$directory for group:$group with perms:$permissions"

    /bin/chmod +a "$group:$ace" "$directory"
	chmodCode1=$?
	if [ $? != 0 ]; then
		logger -s -t "$scriptTag" "  - Failed applying ACL to top level of dir:$directory code:$chmodCode1... exiting!"
		return $chmodCode1
	fi	

	/bin/chmod -f -R +ai "$group:$ace" "$directory"/*
	chmodCode2=$?
	if [ $? != 0 ]; then
		logger -s -t "$scriptTag" "  - Failed applying ACL to dir:$directory code:$chmodCode2"
		return $chmodCode2
	fi

	return 0
} ## end setACLForGroup()



######### START #############
#############################

## Iterate through all of our specified homeDirectories.
OLDIFS=$IFS
IFS=','
for homeEntry in $homeDirectories; do
    ## check to ensure we have a good homeLoc
    homeLoc=$(echo $homeEntry | awk -F: '{print$1}')
    homeDepth=$(echo $homeEntry | awk -F: '/[0-9]/ {print$2}')
    
    if [ -z "$homeDepth" ]; then
        homeDepth=0
    fi
    if [ -d "${homeLoc:?}" ]; then
        cd "$homeLoc"	
    else
        logger -s -t "$scriptTag" "Fatal error, $homeLoc is not a directory"
        errorOccured=true
    fi
    
    if [ $homeDepth == 0 ]; then
        if [ "$restructureHomes" == "true" ]; then
            logger -s -t "$scriptTag" "Restructuring home folders for $homeLoc"
            structureForOSX
        fi
        if [ "$repairPrivs" == "true" ]; then
            logger -s -t "$scriptTag" "Reparing Privileges for $homeLoc"
            repairPrivs
        fi
    else	
        IFS=$OLDIFS
        for homeDir in `ls | grep -v "$orphanageName" | grep -v "Shared" | egrep -v "^\."`; do
            if [ -d "${homeLoc:?}/$homeDir" ]; then
                cd "$homeLoc/$homeDir"
            else
                continue
            fi
            if [ "$repairPrivs" == "true" ]; then
                logger -s -t "$scriptTag" "Reparing Privileges for $homeLoc/$homeDir"
                repairPrivs
            fi
            cd ..
        done
    fi

    ## Deploy our aclGroups to the root of the home directory
    if [ ! -z "$aclGroups" ]; then
        IFS=$'\,'
        for group in $aclGroups; do
            groupName=`printf "$group" | awk -F: '{print$1}'`
            groupRights=`printf "$group" | awk -F: '{print$2}'`
            setACLForGroup "$homeLoc" "$groupName" "$groupRights"
        done
    fi
done
